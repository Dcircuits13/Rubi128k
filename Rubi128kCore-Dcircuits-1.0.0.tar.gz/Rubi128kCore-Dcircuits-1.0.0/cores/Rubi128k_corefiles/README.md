# Arduino core files for Rubi128K core

This repo contains the Arduino corefiles used with [MightyCore](https://github.com/MCUdude/MightyCore), [MegaCore](https://github.com/MCUdude/MegaCore), [MiniCore](https://github.com/MCUdude/MiniCore) and [MajorCore](https://github.com/MCUdude/MightyCore).

## Supported devices
* ATmega128

## Supported clock frequencies
By supported I mean clocks that accurate timing is implemented for (millis, micros, delay, delayMicroseconds).

* 16 MHz
